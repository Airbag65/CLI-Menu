class IllegalArgumentError(ValueError):
    pass

